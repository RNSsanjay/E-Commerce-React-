import React from 'react';
import { useParams } from 'react-router-dom';
import './ProductDetails.css';

function ProductDetails({ addToCart }) {
  const { id } = useParams();
  const product = {
    id: id,
    name: `Product ${id}`,
    price: id * 100,
    description: `This is the detailed description of Product ${id}.`,
    image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain',
  };

  return (
    <div className="product-details">
      <img src={product.image} alt={product.name} />
      <h2>{product.name}</h2>
      <p>{product.description}</p>
      <h3>Price: ${product.price}</h3>
      <button onClick={() => addToCart(product)}>Add to Cart</button>
    </div>
  );
}

export default ProductDetails;
