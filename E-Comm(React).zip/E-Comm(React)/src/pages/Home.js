import React from 'react';
import './Home.css';

function Home() {
  return (
    <div className="home">
      <header className="home-header">
        <h1>Welcome to RNS Luxe</h1>
        <p>Explore our premium collection of fashion, electronics, and more. Enjoy exclusive deals and unparalleled quality!</p>
      </header>

      <section className="home-products">
        <h2>Featured Products</h2>
        <div className="product-grid">
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 1" />
            <div className="product-info">
              <h3>Product 1</h3>
              <p>Elegant and stylish, perfect for any occasion.</p>
            </div>
          </div>
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 2" />
            <div className="product-info">
              <h3>Product 2</h3>
              <p>High-quality craftsmanship for the modern individual.</p>
             
            </div>
          </div>
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 3" />
            <div className="product-info">
              <h3>Product 3</h3>
              <p>Comfort and style combined for a perfect fit.</p>
             
            </div>
          </div>
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 1" />
            <div className="product-info">
              <h3>Product 1</h3>
              <p>Elegant and stylish, perfect for any occasion.</p>
            </div>
          </div>

          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 1" />
            <div className="product-info">
              <h3>Product 1</h3>
              <p>Elegant and stylish, perfect for any occasion.</p>
            </div>
          </div>
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 1" />
            <div className="product-info">
              <h3>Product 1</h3>
              <p>Elegant and stylish, perfect for any occasion.</p>
            </div>
          </div>
          <div className="product-card">
            <img src="https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg" alt="Product 1" />
            <div className="product-info">
              <h3>Product 1</h3>
              <p>Elegant and stylish, perfect for any occasion.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="home-testimonials">
        <h2>What Our Customers Say</h2>
        <div className="testimonial-card">
          <p>"I absolutely love the products from RNS Luxe! The quality and service are unbeatable." - Jane D.</p>
        </div>
        <div className="testimonial-card">
          <p>"Shopping at RNS Luxe is always a pleasure. The products are stylish and the customer service is excellent." - John S.</p>
        </div>
        <div className="testimonial-card">
          <p>"Highly recommend RNS Luxe for anyone looking for fashionable and comfortable items!" - Sarah W.</p>
        </div>
      </section>
    </div>
  );
}

export default Home;
