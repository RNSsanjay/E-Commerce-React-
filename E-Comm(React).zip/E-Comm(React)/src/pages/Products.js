import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Products.css';

function Products({ addToCart, searchQuery }) {
  const [products] = useState([
    { id: 1, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 2, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 3, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 4, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 5, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 6, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 7, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 8, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 9, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 10, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 11, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 12, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 13, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 14, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 15, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 16, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 17, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
    { id: 18, name: 'Smartphone', price: 500, image: 'https://th.bing.com/th/id/OIP.uS9V_b_qJUt0mdaWBXYcWQHaEK?rs=1&pid=ImgDetMain' },
    { id: 19, name: 'Laptop', price: 750, image: 'https://m.media-amazon.com/images/I/71dBdD1EtbL._SX679_.jpg' },
    { id: 20, name: 'Headphones', price: 50, image: 'https://images-na.ssl-images-amazon.com/images/I/71Rz4nN%2BNFL._AC_SL1500_.jpg' },
  ]);

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="products">
      <h2>Products</h2>
      <div className="product-list">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <div key={product.id} className="product-card">
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p>${product.price}</p>
              <button onClick={() => addToCart(product)}>Add to Cart</button>
              <Link to={`/product/${product.id}`} className="details-link">View Details</Link>
            </div>
          ))
        ) : (
          <p>No products found</p>
        )}
      </div>
    </div>
  );
}

export default Products;
