import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar({ cartCount, setSearchQuery }) {
  return (
    <nav className="navbar">
      <h1 className="navbar-logo">RNS Luxe</h1>
      <input
        type="text"
        className="search-bar"
        placeholder="Search products..."
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <ul className="navbar-links">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/cart">Cart ({cartCount})</Link></li>
      </ul>
    </nav>
  );
}

export default Navbar;
